
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Login</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="../assets/css/style.css" rel="stylesheet">
        <link href="sign-in.css" rel="stylesheet">
    </head>
    <body>
<header>
<?php include '../navbar-fixed/navbar2.html'; ?>
</header>

<main>
<div style="height: 56px;"></div>
</main>

   <h2 class="text-center my-4">Iniciar Sesion</h2>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form>
                    <div class="mb-3">
                        <label for="email" class="form-label">Correo Electrónico</label>
                        <input type="email" class="form-control" id="email" placeholder="Correo electrónico">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" id="password" placeholder="Tu contraseña">
                    </div>
                    <button type="submit" class="btn btn-enviar">Iniciar Sesion</button>
                </form>
            </div>
        </div>
    </div>

<div style="height: 200px;"></div>

<!-- Footer -->
    <?php include '../footers/index.html'; ?>
            
    </body>
</html>