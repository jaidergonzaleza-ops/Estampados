
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Contacto</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
<style>
        body {
            padding-top: 50px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .form-control {
            background-color: #d3d3d3;
            border: none;
        }
        .form-control:focus {
            box-shadow: none;
        }
        textarea.form-control {
            height: 120px;
        }
        .btn-enviar {
            background-color: #3f74ff;
            color: white;
            border: none;
            width: 100%;
            padding: 10px;
            font-weight: bold;
        }
        .btn-enviar:hover {
            background-color: #335ecc;
        }
    </style>
    </head>
    <body>
<header>
<?php include 'navbar-fixed/navbar.html'; ?>
</header>

<main>
<div style="height: 56px;"></div>
</main>

   <h2 class="text-center my-4">Contacto</h2>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form>
                    <div class="mb-3">
                        <label for="name" class="form-label">Nombre</label>
                        <input type="text" class="form-control" id="name" placeholder="Tu nombre">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Correo Electrónico</label>
                        <input type="email" class="form-control" id="email" placeholder="Correo electrónico">
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Teléfono</label>
                        <input type="tel" class="form-control" id="phone" placeholder="Tu número de teléfono">
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Mensaje</label>
                        <textarea class="form-control" id="message" rows="4" placeholder="Escribe tu mensaje aquí"></textarea>
                    </div>
                    <button type="submit" class="btn btn-enviar">Enviar</button>
                </form>
            </div>
        </div>
    </div> 
    
<div style="height: 200px;"></div>

    <!-- Footer -->
    <?php include 'footers/index.html'; ?>
            
    </body>
</html>