Título del proyecto: Estampados
Descripción:El sitio incluye páginas principales con Bootstrap, estilos personalizados, navegación adaptable (barra de navegación fija), banners con imágenes y un sistema de inicio de sesión básico en PHP.
Instrucciones de instalación o de uso: El usuario puede iniciar sesión, realizar pedidos y contactar
Estructura de carpetas o archivos principales: README.txt, Visión y Diseño.pdf
Autores o colaboradores: Jaider David González Alarcón, Nolberto Manuel Morelo Agamez

Licencia: (Si aplica).