<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Productos</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/style.css" rel="stylesheet">
    </head>

    <body>
<header>
  <!-- Barra de navegación -->
  <?php include 'navbar-fixed/navbar.html'; ?>
</header>

<main>
<div style="height: 56px;"></div>
</main>

  <!-- Galería de productos -->
   <h2 class="text-center my-4">Productos</h2>
  <div class="album py-5 bg-light">
    <div class="container">
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

        <div class="col">
          <div class="card shadow-sm">
            <img src="assets/img/producto1.jpg" class="card-img-top" alt="Producto 1">
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button class="btn btn-sm btn-outline-secondary">Ver</button>
                  <button class="btn btn-sm btn-outline-secondary">Comprar</button>
                </div>
                <small class="text-muted">$</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="assets/img/producto2.jpg" class="card-img-top" alt="Producto 2">
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button class="btn btn-sm btn-outline-secondary">Ver</button>
                  <button class="btn btn-sm btn-outline-secondary">Comprar</button>
                </div>
                <small class="text-muted">$</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="assets/img/producto3.jpg" class="card-img-top" alt="Producto 3">
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button class="btn btn-sm btn-outline-secondary">Ver</button>
                  <button class="btn btn-sm btn-outline-secondary">Comprar</button>
                </div>
                <small class="text-muted">$</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="assets/img/producto3.jpg" class="card-img-top" alt="Producto 4">
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button class="btn btn-sm btn-outline-secondary">Ver</button>
                  <button class="btn btn-sm btn-outline-secondary">Comprar</button>
                </div>
                <small class="text-muted">$</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="assets/img/producto3.jpg" class="card-img-top" alt="Producto 5">
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button class="btn btn-sm btn-outline-secondary">Ver</button>
                  <button class="btn btn-sm btn-outline-secondary">Comprar</button>
                </div>
                <small class="text-muted">$</small>
              </div>
            </div>
          </div>
        </div>

        <div class="col">
          <div class="card shadow-sm">
            <img src="assets/img/producto3.jpg" class="card-img-top" alt="Producto 6">
            <div class="card-body">
              <p class="card-text"></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button class="btn btn-sm btn-outline-secondary">Ver</button>
                  <button class="btn btn-sm btn-outline-secondary">Comprar</button>
                </div>
                <small class="text-muted">$</small>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

    <!-- Footer -->
    <?php include 'footers/index.html'; ?>

    </body>
</html>