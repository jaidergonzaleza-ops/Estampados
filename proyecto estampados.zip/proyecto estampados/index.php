<!doctype html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tienda de Prendas Estampadas</title>
    <link href="assets/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
  </head>
  <body>
    
<header>
<?php include 'navbar-fixed/navbar.html'; ?>
</header>

<main>

<!-- Carousel -->
<div id="myCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2"></button>
  </div>

  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="assets/img/banner 1.jpg" class="d-block w-100 carousel-img" alt="Prenda 1">
      <div class="container">
        <div class="carousel-caption text-start">
          <h1>Nueva colección</h1>
          <p>Descubre nuestras últimas prendas estampadas.</p>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <img src="assets/img/banner 2.jpg" class="d-block w-100 carousel-img" alt="Prenda 2">
      <div class="container">
        <div class="carousel-caption">
          <h1>Diseños únicos</h1>
          <p>Personaliza tu prenda a tu estilo.</p>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <img src="assets/img/banner 3.jpg" class="d-block w-100 carousel-img" alt="Prenda 3">
      <div class="container">
        <div class="carousel-caption text-end">
          <h1>Ofertas especiales</h1>
          <p>Aprovecha descuentos exclusivos.</p>
        </div>
      </div>
    </div>
  </div>

  <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
    <span class="visually-hidden">Anterior</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
    <span class="visually-hidden">Siguiente</span>
  </button>
</div>


    <?php include 'productos.php'; ?>

</main>


<script src="assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/nav.js"></script>
  </body>
</html>
