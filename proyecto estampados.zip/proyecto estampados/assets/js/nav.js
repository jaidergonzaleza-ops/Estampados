window.addEventListener("scroll", function () {
    const navbar = document.getElementById("mainNavbar");
    if (window.scrollY > 300) {
      navbar.classList.add("navbar-scrolled");
      navbar.classList.remove("transparent-navbar");
    } else {
      navbar.classList.add("transparent-navbar");
      navbar.classList.remove("navbar-scrolled");
    }
  });
